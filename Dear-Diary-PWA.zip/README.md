# Dear Diary — Android PWA

A minimalist, dark-themed personal diary. Data is stored in the browser's localStorage on the device. It does not use a server or cloud account.

## Install on Android
1. Publish the contents of this folder to a static HTTPS host (for example, Netlify Drop or GitHub Pages).
2. Open the HTTPS website in Chrome on Android.
3. Open Chrome's ⋮ menu and choose **Install app** or **Add to Home screen**.
4. Launch Dear Diary from the new home-screen icon.

A PWA needs HTTPS (or localhost) to install and use its service worker. Simply opening index.html from a ZIP/file manager does not provide full PWA installation/offline functionality.

## Publish with Netlify Drop
1. Extract this ZIP.
2. Visit https://app.netlify.com/drop in a browser and sign in if prompted.
3. Drag the extracted `my_personal_diary_pwa` folder (the folder containing index.html) onto the page.
4. Wait for a public HTTPS URL, then open it on your Android phone in Chrome and install it.

## Features
- Daily entries, mood, gratitude and tomorrow's intention
- Search, edit and delete entries
- Print / Save as PDF
- JSON backup and restore
- Offline app shell after first successful visit

## Privacy and limitations
- Entries are stored locally in the browser profile, not encrypted.
- Clearing browser site data can erase entries. Export JSON backups regularly.
- Installing the PWA does not automatically migrate entries from the earlier in-chat prototype.
- The PDF option opens the browser print dialog; select Save as PDF.
